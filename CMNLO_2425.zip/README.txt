﻿CMNLO 2024/2025 - Inverted pendulum 
===================================

1 - State model saved in "IP_MODEL.mat" (loaded in the next step);

2 - Run "IP_MACRO.m";

3 - Open and run "IP_TEST_MIO16E4_2015a.slx" or "IP_TEST_PCI6221_2015a.slx", accordingly;

4 - Open and run "IP_MIO16E4_2015a.slx" or "IP_LQG_PCI6221_2015a.slx", accordingly.

